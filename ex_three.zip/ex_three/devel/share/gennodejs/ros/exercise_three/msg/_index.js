
"use strict";

let UserInfo = require('./UserInfo.js');

module.exports = {
  UserInfo: UserInfo,
};
