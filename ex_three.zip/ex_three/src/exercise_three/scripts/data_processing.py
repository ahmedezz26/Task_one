#!/usr/bin/env python
import rospy
import re
from std_msgs.msg import String
from std_msgs.msg import Int64
from std_msgs.msg import Float64
from exercise_three.msg import UserInfo

global info
global name

def callback(data):
    message = data.data

    info = [int(i) for i in message.split() if i.isdigit()]
    name = message.rsplit(", ")[0]
   
    rospy.loginfo("%s",name)
    rospy.loginfo("age: %d",info[0])
    rospy.loginfo("height: %d",info[1])
    UserInfo.name = name
    UserInfo.age = info[0]
    UserInfo.height = info[1]
    pub = rospy.Publisher('user_info', UserInfo, queue_size=10)
    pub.publish(UserInfo)




def data_processing():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('data_processing', anonymous=True)

    rospy.Subscriber("raw_data", String, callback)


    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    data_processing()
